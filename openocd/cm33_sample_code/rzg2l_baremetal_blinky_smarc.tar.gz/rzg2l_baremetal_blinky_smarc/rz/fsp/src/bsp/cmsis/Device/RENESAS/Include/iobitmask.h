#ifndef __RZG2L___IOBITMASK_HEADER__
#define __RZG2L___IOBITMASK_HEADER__

#include "iobitmasks/accctl_iobitmask.h"
#include "iobitmasks/cpg_iobitmask.h"
#include "iobitmasks/gpio_iobitmask.h"
#include "iobitmasks/gpt_iobitmask.h"
#include "iobitmasks/gtm_iobitmask.h"
#include "iobitmasks/intc_im33_iobitmask.h"
#include "iobitmasks/mhu_iobitmask.h"
#include "iobitmasks/mstp_iobitmask.h"
#include "iobitmasks/poeg_iobitmask.h"
#include "iobitmasks/riic_iobitmask.h"
#include "iobitmasks/scifa_iobitmask.h"
#include "iobitmasks/spibsc_iobitmask.h"
#include "iobitmasks/sysc_iobitmask.h"
#include "iobitmasks/wdt_iobitmask.h"

#endif
