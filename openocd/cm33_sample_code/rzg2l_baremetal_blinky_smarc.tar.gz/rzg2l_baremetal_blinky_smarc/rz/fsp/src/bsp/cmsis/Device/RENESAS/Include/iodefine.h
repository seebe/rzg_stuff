#ifndef __RZG2L___IODEFINE_HEADER__
#define __RZG2L___IODEFINE_HEADER__

#include "iodefines/accctl_iodefine.h"
#include "iodefines/cpg_iodefine.h"
#include "iodefines/gpio_iodefine.h"
#include "iodefines/gpt_iodefine.h"
#include "iodefines/gtm_iodefine.h"
#include "iodefines/intc_im33_iodefine.h"
#include "iodefines/mhu_iodefine.h"
#include "iodefines/mstp_iodefine.h"
#include "iodefines/poeg_iodefine.h"
#include "iodefines/riic_iodefine.h"
#include "iodefines/scifa_iodefine.h"
#include "iodefines/spibsc_iodefine.h"
#include "iodefines/sysc_iodefine.h"
#include "iodefines/wdt_iodefine.h"

#endif
