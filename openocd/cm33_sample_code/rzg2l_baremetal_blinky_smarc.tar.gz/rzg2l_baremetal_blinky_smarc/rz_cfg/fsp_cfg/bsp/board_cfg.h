/* generated configuration header file - do not edit */
#ifndef BOARD_CFG_H_
#define BOARD_CFG_H_
#include "../../../rz/board/rzg2l_ek/board.h"
#endif /* BOARD_CFG_H_ */
